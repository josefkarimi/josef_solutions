def game(number):
    return abs((number % 10)-(number //10))


# print(game())